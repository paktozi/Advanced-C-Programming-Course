﻿using System;

namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            RaceMotorcycle car = new(10,100);
              
            
            Console.WriteLine(car.FuelConsumption);
        
        }
    }
}
